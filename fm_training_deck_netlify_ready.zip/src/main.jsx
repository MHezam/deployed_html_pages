
import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import Deck from './fm_training_storyline_interactive_html_deck'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Deck />
  </React.StrictMode>
)
